<template>
  <h1>404: 您查找的页面不存在 </h1>
</template>
<script>
export default {
  
}
</script>
<style scoped>
  h1{ /*h1[data-v-xxxxxx]*/
    color:red;
  }
</style>